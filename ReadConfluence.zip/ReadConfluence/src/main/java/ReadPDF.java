import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReadPDF {
    public static void main(String[] args) throws IOException {
//        WriteToCSV writeToCSV = new WriteToCSV();
//        writeToCSV.writeFirstQuestionToCSV("Q4.Ce efecte produce lipsa interesul economic? ","test.csv");
        readFromTxt("faq.txt");

    }

    public static boolean isQuestionLine(String line) {
        if(line.startsWith("Q") || line.startsWith(" Q")) {
            Pattern pattern = Pattern.compile("Q\\d+");
            Matcher matcher = pattern.matcher(line);
            boolean matchFound = matcher.find();
            return matchFound;
        }
        else
            return false;
    }

    public static void readFromTxt(String inputPath)
    {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(inputPath));
            String line = reader.readLine();
            while (line != null) {
                System.out.println(line);
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
